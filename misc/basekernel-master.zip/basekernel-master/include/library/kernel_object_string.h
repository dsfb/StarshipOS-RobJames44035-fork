#ifndef KERNEL_OBJECT_STRING_H
#define KERNEL_OBJECT_STRING_H

const char *kernel_object_string( kobject_type_t type );

#endif
