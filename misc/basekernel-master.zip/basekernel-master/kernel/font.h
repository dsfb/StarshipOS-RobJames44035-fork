#ifndef FONT_H
#define FONT_H

extern unsigned char fontdata[];

#define FONT_WIDTH 8
#define FONT_HEIGHT 8

#endif
